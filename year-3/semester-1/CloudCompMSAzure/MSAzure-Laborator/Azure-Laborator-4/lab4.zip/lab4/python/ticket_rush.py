"""Ticket rush: 10 buyers, 100 concert seats, one blob.

Usage:
    python ticket_rush.py <storage-account> naive
    python ticket_rush.py <storage-account> safe

seats.json holds the number of free seats, e.g. {"remaining": 100}.
sales.log is an append blob: one line for every ticket sold.
"""
import json
import os
import sys
import threading
import time

from azure.core import MatchConditions
from azure.core.exceptions import ResourceModifiedError
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient

SEATS = 100
BUYERS = ["Alice", "Bob", "Carol", "Dave", "Erin", "Frank", "Grace", "Heidi", "Ivan", "Judy"]
PAYMENT_TIME = 0.02  # seconds a buyer needs to pay, between reading and writing the seats


def connect(account):
    """Signs in with your Microsoft Entra identity (in Cloud Shell: you)."""
    conn = os.environ.get("STORAGE_CONNECTION_STRING")  # optional: local tests with Azurite
    if conn:
        return BlobServiceClient.from_connection_string(conn)
    return BlobServiceClient(f"https://{account}.blob.core.windows.net",
                             credential=DefaultAzureCredential())


def to_json(remaining):
    return json.dumps({"remaining": remaining})


def from_json(data):
    return json.loads(data)["remaining"]


def buy_naive(seats, stats):
    """Buy one ticket: read the seats, pay, write them back. Returns False when sold out."""
    remaining = from_json(seats.download_blob().readall())
    if remaining == 0:
        return False
    time.sleep(PAYMENT_TIME)  # the buyer pays
    seats.upload_blob(to_json(remaining - 1), overwrite=True)
    return True


def buy_safe(seats, stats):
    """TODO 1: buy one ticket without overbooking. Returns False when sold out.

    Like buy_naive, but the write must fail if someone changed seats.json after
    you read it (ETag + If-Match). On a conflict call stats.add_conflict() and
    try again. See Step 8 in the lab for the SDK calls.
    """
    raise NotImplementedError("TODO 1: implement buy_safe")


def log_sale(log, buyer):
    """TODO 2: add the line "<buyer>\\n" at the end of sales.log (an append blob).
    See Step 7 in the lab."""
    pass


class Stats:
    """Counters shared by the buyer threads."""

    def __init__(self):
        self.lock = threading.Lock()
        self.sold = dict.fromkeys(BUYERS, 0)
        self.conflicts = 0
        self.errors = []

    def add_sale(self, buyer):
        with self.lock:
            self.sold[buyer] += 1

    def add_conflict(self):
        with self.lock:
            self.conflicts += 1


def run_buyer(name, buy, seats, log, stats):
    try:
        while buy(seats, stats):
            stats.add_sale(name)
            log_sale(log, name)
    except Exception as error:  # reported by the main thread
        stats.errors.append(error)


def main():
    if len(sys.argv) != 3 or sys.argv[2] not in ("naive", "safe"):
        sys.exit("usage: python ticket_rush.py <storage-account> naive|safe")
    account, mode = sys.argv[1], sys.argv[2]

    container = connect(account).get_container_client("rush")
    if not container.exists():
        container.create_container()
    seats = container.get_blob_client("seats.json")
    log = container.get_blob_client("sales.log")
    seats.upload_blob(to_json(SEATS), overwrite=True)
    log.create_append_blob()  # a new, empty sales.log

    print(f"{len(BUYERS)} buyers, {SEATS} seats, mode: {mode}")
    stats = Stats()
    buy = buy_naive if mode == "naive" else buy_safe
    threads = [threading.Thread(target=run_buyer, args=(name, buy, seats, log, stats))
               for name in BUYERS]
    start = time.time()
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    elapsed = time.time() - start
    if stats.errors:
        sys.exit(f"Error: {stats.errors[0]}")

    sold = sum(stats.sold.values())
    lines = log.download_blob().readall().decode().count("\n")
    print("Sold per buyer:    ", ", ".join(f"{name} {count}" for name, count in stats.sold.items()))
    print(f"Tickets sold:       {sold}")
    print(f"Seats left:         {from_json(seats.download_blob().readall())}")
    print(f"Lines in sales.log: {lines}")
    print(f"Conflicts (412):    {stats.conflicts}")
    print(f"Time:               {elapsed:.1f} s")
    if sold > SEATS:
        print(f"OVERBOOKED: {sold - SEATS} more tickets than seats!")


if __name__ == "__main__":
    main()
