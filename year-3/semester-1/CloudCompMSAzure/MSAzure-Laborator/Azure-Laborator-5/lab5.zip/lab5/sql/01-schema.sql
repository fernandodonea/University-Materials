-- Lab 5 - Step 4: the tables of DocsApi. Run it as the server admin:
--   sqlcmd $AS_ADMIN -i sql/01-schema.sql
-- It drops and recreates the tables: to start over, run it, then 02-app-user.sql and 03-seed.sql.

DROP TABLE IF EXISTS dbo.Documents;
DROP TABLE IF EXISTS dbo.Owners;
GO

-- The owners of the documents (in a real project they come from Microsoft Entra ID).
CREATE TABLE dbo.Owners (
    OwnerId     VARCHAR(64)   NOT NULL CONSTRAINT PK_Owners PRIMARY KEY,
    DisplayName NVARCHAR(100) NOT NULL
);

-- One row for each document. The file itself is a blob in Blob Storage: BlobName links the two.
CREATE TABLE dbo.Documents (
    DocumentId   UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_Documents PRIMARY KEY,
    OwnerId      VARCHAR(64)      NOT NULL
                 CONSTRAINT FK_Documents_Owners REFERENCES dbo.Owners (OwnerId),
    OriginalName NVARCHAR(260)    NOT NULL,
    BlobName     NVARCHAR(400)    NOT NULL CONSTRAINT UQ_Documents_BlobName UNIQUE,
    Status       VARCHAR(20)      NOT NULL
                 CONSTRAINT CK_Documents_Status
                 CHECK (Status IN ('Pending', 'Uploaded', 'Processing', 'Processed', 'Failed')),
    CreatedAtUtc DATETIME2        NOT NULL
                 CONSTRAINT DF_Documents_CreatedAtUtc DEFAULT SYSUTCDATETIME()
);
GO

-- The rules the database checks at every write
SELECT name AS rule_name, type_desc
FROM sys.objects
WHERE parent_object_id = OBJECT_ID('dbo.Documents')
ORDER BY name;
