-- Lab 5 - Step 11: 50,000 more documents, one every 7 minutes back in time. Run it once,
-- as the server admin:
--   sqlcmd $AS_ADMIN -i sql/06-bulk.sql
-- GENERATE_SERIES(1, 50000) returns the numbers 1 to 50000 in a column named value.

SET NOCOUNT ON;

INSERT INTO dbo.Documents (DocumentId, OwnerId, OriginalName, BlobName, Status, CreatedAtUtc)
SELECT NEWID(),
       CASE value % 3 WHEN 0 THEN 'u-41' WHEN 1 THEN 'u-42' ELSE 'u-43' END,
       CONCAT(N'file-', value, N'.pdf'),
       CONCAT(N'bulk/', value, N'.pdf'),
       CASE value % 20 WHEN 0 THEN 'Failed'
                       WHEN 1 THEN 'Pending'
                       WHEN 2 THEN 'Uploaded'
                       WHEN 3 THEN 'Processing'
                       ELSE 'Processed' END,
       DATEADD(MINUTE, -7 * value, SYSUTCDATETIME())
FROM GENERATE_SERIES(1, 50000);

SELECT Status, COUNT(*) AS documents
FROM dbo.Documents
GROUP BY Status
ORDER BY Status;
