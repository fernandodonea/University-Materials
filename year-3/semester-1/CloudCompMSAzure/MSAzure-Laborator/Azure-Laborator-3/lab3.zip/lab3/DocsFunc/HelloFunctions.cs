using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;

namespace DocsFunc;

public class HelloFunctions
{
    // GET /api/hello?name=Alice - the function reads the name from the query string
    [Function("Hello")]
    public IActionResult Run(
        [HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequest req)
        => new OkObjectResult(
            $"Hello, {req.Query["name"].FirstOrDefault() ?? "student"}!");

    // GET /api/hello2/Alice - the trigger passes the name from the route
    [Function("Hello2")]
    public IActionResult Run2(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "hello2/{name}")]
        HttpRequest req,
        string name)
        => new OkObjectResult($"Hello, {name}!");
}
