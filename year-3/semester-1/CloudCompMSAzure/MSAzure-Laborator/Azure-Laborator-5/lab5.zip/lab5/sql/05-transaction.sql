-- Lab 5 - Step 10: all or nothing? Run it as the user of the API:
--   sqlcmd $AS_APP -i sql/05-transaction.sql
-- d-101 finished processing and d-102 starts processing: both changes must be saved together.
-- A bug in the new version of the API writes the status 'Queued', which the CHECK rejects.

-- Start from the same state at every run
UPDATE dbo.Documents SET Status = 'Processing'
WHERE DocumentId = '00000000-0000-0000-0000-000000000101';
UPDATE dbo.Documents SET Status = 'Uploaded'
WHERE DocumentId = '00000000-0000-0000-0000-000000000102';
GO

-- TODO: add one line here, so that an error cancels the whole transaction
BEGIN TRANSACTION;
    UPDATE dbo.Documents SET Status = 'Processed'
    WHERE DocumentId = '00000000-0000-0000-0000-000000000101';
    UPDATE dbo.Documents SET Status = 'Queued'
    WHERE DocumentId = '00000000-0000-0000-0000-000000000102';
COMMIT;
GO

SELECT DocumentId, Status
FROM dbo.Documents
WHERE DocumentId IN ('00000000-0000-0000-0000-000000000101',
                     '00000000-0000-0000-0000-000000000102');
