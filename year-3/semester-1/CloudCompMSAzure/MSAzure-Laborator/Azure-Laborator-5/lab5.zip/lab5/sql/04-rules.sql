-- Lab 5 - Step 9: break the rules. Run it as the user of the API:
--   sqlcmd $AS_APP -i sql/04-rules.sql

-- A valid INSERT. It works every time: each run creates a new id and a new BlobName.
-- CreatedAtUtc is missing, so it gets its DEFAULT value.
DECLARE @id UNIQUEIDENTIFIER = NEWID();
INSERT INTO dbo.Documents (DocumentId, OwnerId, OriginalName, BlobName, Status)
VALUES (@id, 'u-42', N'notes.txt', CONCAT(N'u-42/', @id, N'.txt'), 'Pending');

-- TODO: write one INSERT for each rule below, under its comment.
-- Each INSERT must break only that rule, and the database must reject it.

-- NOT NULL: leave out OriginalName

-- PRIMARY KEY: reuse the DocumentId of d-101, '00000000-0000-0000-0000-000000000101'

-- UNIQUE: reuse the BlobName of d-101, N'u-42/7f3c2a10.pdf'

-- CHECK: a status that isn't in the list, e.g. 'Queued'

-- FOREIGN KEY: an owner that doesn't exist, e.g. 'u-99'
