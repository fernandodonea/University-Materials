#!/usr/bin/env bash
# Lab 5: builds DocsApi, stops the copy that is already running and starts the new one in the
# background on http://localhost:5080. Run it from ~/lab5/DocsApi with: bash run.sh
cd "$(dirname "$0")" || exit 1
DLL=bin/Release/net9.0/DocsApi.dll

pkill -f "$DLL" && sleep 1
dotnet build -c Release --nologo -v quiet || exit 1

# Development: the API reads the connection string from User Secrets
ASPNETCORE_ENVIRONMENT=Development nohup dotnet "$DLL" --urls http://localhost:5080 \
    > api.log 2>&1 &

for i in $(seq 1 20); do
    sleep 1
    curl -s -o /dev/null localhost:5080/ && break
done

if HEALTH=$(curl -s localhost:5080/api/health); then
    echo "$HEALTH"
    if [[ "$HEALTH" == *sqlError* ]]; then
        echo "The API runs, but the database refused it: read the message above."
    fi
else
    echo "The API isn't running. The end of api.log:"
    tail -n 15 api.log
fi
