-- Lab 5 - Step 11: the index for "Failed today, newest first". Run it as the server admin:
--   sqlcmd $AS_ADMIN -i sql/08-index.sql
-- The rows are sorted by Status, then by CreatedAtUtc (newest first). INCLUDE copies
-- OriginalName into the index, so the query doesn't have to open the table at all.

CREATE INDEX IX_Documents_Status_Created
    ON dbo.Documents (Status, CreatedAtUtc DESC)
    INCLUDE (OriginalName);
