// Ticket rush: 10 buyers, 100 concert seats, one blob.
//   dotnet run -- <storage-account> naive
//   dotnet run -- <storage-account> safe
// seats.json holds the number of free seats, e.g. {"remaining":100}.
// sales.log is an append blob: one line for every ticket sold.
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text.Json;
using Azure;
using Azure.Identity;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs.Specialized;

if (args.Length != 2 || args[1] is not ("naive" or "safe"))
{
    Console.WriteLine("usage: dotnet run -- <storage-account> naive|safe");
    return 1;
}
var (account, mode) = (args[0], args[1]);

var container = Rush.Connect(account).GetBlobContainerClient("rush");
await container.CreateIfNotExistsAsync();
var seats = container.GetBlobClient("seats.json");
var log = container.GetAppendBlobClient("sales.log");
await seats.UploadAsync(Rush.ToJson(Rush.Seats), overwrite: true);
await log.CreateAsync();  // a new, empty sales.log

Console.WriteLine($"{Rush.Buyers.Length} buyers, {Rush.Seats} seats, mode: {mode}");
var stats = new Stats(Rush.Buyers);
Func<BlobClient, Stats, Task<bool>> buy = mode == "naive" ? Rush.BuyNaiveAsync : Rush.BuySafeAsync;
var clock = Stopwatch.StartNew();
await Task.WhenAll(Rush.Buyers.Select(name => Task.Run(async () =>
{
    while (await buy(seats, stats))
    {
        stats.AddSale(name);
        await Rush.LogSaleAsync(log, name);
    }
})));
var elapsed = clock.Elapsed.TotalSeconds;

var sold = stats.TotalSold;
var lines = (await log.DownloadContentAsync()).Value.Content.ToString().Count(c => c == '\n');
var left = Rush.FromJson((await seats.DownloadContentAsync()).Value.Content);
Console.WriteLine($"Sold per buyer:     {stats.PerBuyer}");
Console.WriteLine($"Tickets sold:       {sold}");
Console.WriteLine($"Seats left:         {left}");
Console.WriteLine($"Lines in sales.log: {lines}");
Console.WriteLine($"Conflicts (412):    {stats.Conflicts}");
Console.WriteLine($"Time:               {elapsed:F1} s");
if (sold > Rush.Seats)
    Console.WriteLine($"OVERBOOKED: {sold - Rush.Seats} more tickets than seats!");
return 0;

static class Rush
{
    public const int Seats = 100;
    public static readonly string[] Buyers =
        ["Alice", "Bob", "Carol", "Dave", "Erin", "Frank", "Grace", "Heidi", "Ivan", "Judy"];
    static readonly TimeSpan PaymentTime = TimeSpan.FromMilliseconds(20);  // between reading and writing the seats

    // Signs in with your Microsoft Entra identity (in Cloud Shell: you).
    public static BlobServiceClient Connect(string account)
    {
        var conn = Environment.GetEnvironmentVariable("STORAGE_CONNECTION_STRING");  // optional: local tests with Azurite
        return conn is not null
            ? new BlobServiceClient(conn)
            : new BlobServiceClient(new Uri($"https://{account}.blob.core.windows.net"), new DefaultAzureCredential());
    }

    public static BinaryData ToJson(int remaining) => BinaryData.FromString($"{{\"remaining\":{remaining}}}");

    public static int FromJson(BinaryData data) =>
        JsonDocument.Parse(data.ToMemory()).RootElement.GetProperty("remaining").GetInt32();

    // Buy one ticket: read the seats, pay, write them back. Returns false when sold out.
    public static async Task<bool> BuyNaiveAsync(BlobClient seats, Stats stats)
    {
        var remaining = FromJson((await seats.DownloadContentAsync()).Value.Content);
        if (remaining == 0) return false;
        await Task.Delay(PaymentTime);  // the buyer pays
        await seats.UploadAsync(ToJson(remaining - 1), overwrite: true);
        return true;
    }

    // TODO 1: buy one ticket without overbooking. Returns false when sold out.
    // Like BuyNaiveAsync, but the write must fail if someone changed seats.json after
    // you read it (ETag + If-Match). On a conflict call stats.AddConflict() and try again.
    // See Step 8 in the lab for the SDK calls.
    public static Task<bool> BuySafeAsync(BlobClient seats, Stats stats) =>
        throw new NotImplementedException("TODO 1: implement BuySafeAsync");

    // TODO 2: add the line "<buyer>\n" at the end of sales.log (an append blob).
    // See Step 7 in the lab.
    public static Task LogSaleAsync(AppendBlobClient log, string buyer) => Task.CompletedTask;
}

// Counters shared by the buyers.
class Stats
{
    readonly string[] buyers;
    readonly ConcurrentDictionary<string, int> sold = new();
    int conflicts;

    public Stats(string[] buyers)
    {
        this.buyers = buyers;
        foreach (var buyer in buyers) sold[buyer] = 0;
    }

    public void AddSale(string buyer) => sold.AddOrUpdate(buyer, 1, (_, count) => count + 1);
    public void AddConflict() => Interlocked.Increment(ref conflicts);
    public int Conflicts => Volatile.Read(ref conflicts);
    public int TotalSold => sold.Values.Sum();
    public string PerBuyer => string.Join(", ", buyers.Select(buyer => $"{buyer} {sold[buyer]}"));
}
