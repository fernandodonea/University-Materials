const string Version = "1.0";      // change it to prove which version is running

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddHttpClient();
var app = builder.Build();

var startedAt = DateTime.UtcNow;   // when this process started
var requests = 0;                  // kept only in the process memory

app.MapGet("/", () => "DocsApi is running. Try /api/health and /api/info");

app.MapGet("/api/health", () => Results.Ok(new { status = "ok", version = Version }));

app.MapGet("/api/info", (IConfiguration config) =>
{
    var count = Interlocked.Increment(ref requests);
    app.Logger.LogInformation("GET /api/info - request {Count} since start", count);
    return Results.Ok(new
    {
        greeting = config["Greeting"] ?? "(not set)",
        machine = Environment.MachineName,
        startedAt,
        requestsSinceStart = count
    });
});

// Optional part of the lab: the API calls the Hello2 function.
// The address and the key of the function come from app settings, not from the code.
app.MapGet("/api/greet/{name}", async (string name, IConfiguration config,
    IHttpClientFactory factory) =>
{
    var url = config["HelloUrl"];   // https://<function app host>/api/hello2
    var key = config["HelloKey"];   // function key
    if (string.IsNullOrEmpty(url) || string.IsNullOrEmpty(key))
        return Results.Problem("Set the HelloUrl and HelloKey app settings.");

    var http = factory.CreateClient();
    http.DefaultRequestHeaders.Add("x-functions-key", key);
    var answer = await http.GetStringAsync($"{url}/{Uri.EscapeDataString(name)}");
    return Results.Ok(new { api = $"DocsApi {Version}", function = answer });
});

app.Run();
