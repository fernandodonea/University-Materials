-- Lab 5 - Step 4: the database user of the API. Run it as the server admin:
--   sqlcmd $AS_ADMIN -i sql/02-app-user.sql -v APP_PWD=$APP_PWD
-- A contained database user: it exists only in this database and has its own password,
-- so the connection must name the database. Running the script again changes the password.

IF USER_ID('app_docs') IS NULL
    CREATE USER app_docs WITH PASSWORD = '$(APP_PWD)';
ELSE
    ALTER USER app_docs WITH PASSWORD = '$(APP_PWD)';
GO

-- Least privilege: only what the API needs. It reads and adds documents and changes
-- their status. No DELETE, nothing on dbo.Owners, no schema changes (CREATE, ALTER, DROP).
GRANT SELECT, INSERT ON dbo.Documents TO app_docs;
GRANT UPDATE (Status) ON dbo.Documents TO app_docs;
GO

SELECT perm.permission_name,
       COALESCE(OBJECT_NAME(perm.major_id), 'database') AS on_object,
       COL_NAME(perm.major_id, perm.minor_id) AS on_column
FROM sys.database_permissions AS perm
JOIN sys.database_principals AS usr ON usr.principal_id = perm.grantee_principal_id
WHERE usr.name = 'app_docs'
ORDER BY perm.permission_name;
