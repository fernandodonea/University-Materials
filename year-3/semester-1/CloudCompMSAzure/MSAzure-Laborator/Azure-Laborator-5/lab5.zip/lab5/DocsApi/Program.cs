// DocsApi 2.0 - Lab 5: the metadata of the documents lives in Azure SQL Database.
using System.Data;
using Microsoft.Data.SqlClient;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// The code knows only the name of the setting. The value comes from User Secrets in Cloud Shell
// (Step 5) and from the app settings when the API runs in App Service.
string connectionString = app.Configuration.GetConnectionString("DocumentsDb") ?? "";
if (string.IsNullOrWhiteSpace(connectionString))
    throw new InvalidOperationException("ConnectionStrings:DocumentsDb isn't set: see Step 5.");

// Only for the lab: the client sees the SQL error. A real API logs it and hides the details.
app.Use(async (context, next) =>
{
    try
    {
        await next(context);
    }
    catch (SqlException e)
    {
        context.Response.StatusCode = e.Number is 515 or 547 or 2601 or 2627 ? 400 : 500;
        await context.Response.WriteAsJsonAsync(new { sqlError = e.Number, e.Message });
    }
});

app.MapGet("/", () => "DocsApi 2.0 is running. Try /api/health");

// Which database and which database user does the API use?
app.MapGet("/api/health", async (CancellationToken ct) =>
{
    await using var conn = await OpenAsync(ct);
    await using var cmd = new SqlCommand("SELECT DB_NAME(), USER_NAME()", conn);
    await using var reader = await cmd.ExecuteReaderAsync(ct);
    await reader.ReadAsync(ct);
    return Results.Ok(new { database = reader.GetString(0), user = reader.GetString(1) });
});

// How many documents have each status?
app.MapGet("/api/stats", async (CancellationToken ct) =>
{
    await using var conn = await OpenAsync(ct);
    await using var cmd = new SqlCommand(
        "SELECT Status, COUNT(*) FROM dbo.Documents GROUP BY Status ORDER BY Status", conn);
    await using var reader = await cmd.ExecuteReaderAsync(ct);
    var stats = new Dictionary<string, int>();
    while (await reader.ReadAsync(ct))
        stats[reader.GetString(0)] = reader.GetInt32(1);
    return Results.Ok(stats);
});

// The 20 newest documents with a status. A parameterized query: the value travels separately
// from the SQL text, so the database always treats it as data.
app.MapGet("/api/documents", async (string status, CancellationToken ct) =>
{
    await using var conn = await OpenAsync(ct);
    await using var cmd = new SqlCommand(
        "SELECT TOP (20) DocumentId, OwnerId, OriginalName, Status, CreatedAtUtc " +
        "FROM dbo.Documents WHERE Status = @status ORDER BY CreatedAtUtc DESC", conn);
    cmd.Parameters.Add("@status", SqlDbType.VarChar, 20).Value = status;
    return Results.Ok(await ReadDocumentsAsync(cmd, ct));
});

// TODO 1 (Step 12): read the document with this id with a parameterized query.
// Return Results.Ok(document), or Results.NotFound() if there is no such row.
app.MapGet("/api/documents/{id:guid}", async (Guid id, CancellationToken ct) =>
{
    await using var conn = await OpenAsync(ct);
    // Write your code here, then delete the next line.
    return Results.Problem("TODO 1 isn't done yet", statusCode: 501);
});

// A new document starts as Pending. The database checks that the owner exists (FOREIGN KEY).
app.MapPost("/api/documents", async (NewDocument doc, CancellationToken ct) =>
{
    var id = Guid.NewGuid();
    var blobName = $"{doc.OwnerId}/{id}{Path.GetExtension(doc.OriginalName)}";
    await using var conn = await OpenAsync(ct);
    await using var cmd = new SqlCommand(
        "INSERT INTO dbo.Documents (DocumentId, OwnerId, OriginalName, BlobName, Status) " +
        "VALUES (@id, @owner, @name, @blob, 'Pending')", conn);
    cmd.Parameters.Add("@id", SqlDbType.UniqueIdentifier).Value = id;
    cmd.Parameters.Add("@owner", SqlDbType.VarChar, 64).Value = doc.OwnerId;
    cmd.Parameters.Add("@name", SqlDbType.NVarChar, 260).Value = doc.OriginalName;
    cmd.Parameters.Add("@blob", SqlDbType.NVarChar, 400).Value = blobName;
    await cmd.ExecuteNonQueryAsync(ct);
    return Results.Created($"/api/documents/{id}", new { id, blobName, status = "Pending" });
});

// Change the status of a document. The database checks the value (CHECK).
app.MapPut("/api/documents/{id:guid}/status", async (Guid id, StatusChange change,
    CancellationToken ct) =>
{
    await using var conn = await OpenAsync(ct);
    await using var cmd = new SqlCommand(
        "UPDATE dbo.Documents SET Status = @status WHERE DocumentId = @id", conn);
    cmd.Parameters.Add("@status", SqlDbType.VarChar, 20).Value = change.Status;
    cmd.Parameters.Add("@id", SqlDbType.UniqueIdentifier).Value = id;
    var rows = await cmd.ExecuteNonQueryAsync(ct);
    return rows == 0 ? Results.NotFound() : Results.Ok(new { id, status = change.Status });
});

// Search the documents of an owner by name.
// WARNING: open to SQL injection on purpose (Step 7). TODO 2 (Step 13): fix it.
app.MapGet("/api/owners/{ownerId}/documents", async (string ownerId, string? name,
    CancellationToken ct) =>
{
    var sql = "SELECT TOP (20) DocumentId, OwnerId, OriginalName, Status, CreatedAtUtc " +
              $"FROM dbo.Documents WHERE OwnerId = '{ownerId}' AND OriginalName LIKE '%{name}%' " +
              "ORDER BY CreatedAtUtc DESC";
    await using var conn = await OpenAsync(ct);
    await using var cmd = new SqlCommand(sql, conn);
    return Results.Ok(await ReadDocumentsAsync(cmd, ct));
});

app.Run();

async Task<SqlConnection> OpenAsync(CancellationToken ct)
{
    var conn = new SqlConnection(connectionString);
    await conn.OpenAsync(ct);
    return conn;
}

// Reads the documents returned by a query. A batch can contain more than one statement:
// reading all their results also reports their errors.
static async Task<List<Document>> ReadDocumentsAsync(SqlCommand cmd, CancellationToken ct)
{
    var documents = new List<Document>();
    await using var reader = await cmd.ExecuteReaderAsync(ct);
    while (await reader.ReadAsync(ct))
        documents.Add(new Document(reader.GetGuid(0), reader.GetString(1), reader.GetString(2),
            reader.GetString(3), DateTime.SpecifyKind(reader.GetDateTime(4), DateTimeKind.Utc)));
    while (await reader.NextResultAsync(ct)) { }
    return documents;
}

record Document(Guid DocumentId, string OwnerId, string OriginalName, string Status,
    DateTime CreatedAtUtc);
record NewDocument(string OwnerId, string OriginalName);
record StatusChange(string Status);
