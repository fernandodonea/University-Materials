-- Lab 5 - Step 4: sample data, 3 owners and 8 documents. Run it once, as the server admin:
--   sqlcmd $AS_ADMIN -i sql/03-seed.sql
-- The ids are easy to read: d-101 is 00000000-0000-0000-0000-000000000101.

INSERT INTO dbo.Owners (OwnerId, DisplayName)
VALUES ('u-41', N'Alice'), ('u-42', N'Bob'), ('u-43', N'Carol');

INSERT INTO dbo.Documents (DocumentId, OwnerId, OriginalName, BlobName, Status, CreatedAtUtc)
VALUES
    ('00000000-0000-0000-0000-000000000101', 'u-42', N'invoice.pdf', N'u-42/7f3c2a10.pdf',
     'Processing', DATEADD(MINUTE, -30, SYSUTCDATETIME())),
    ('00000000-0000-0000-0000-000000000102', 'u-42', N'contract.pdf', N'u-42/9b41e2c7.pdf',
     'Uploaded', DATEADD(MINUTE, -25, SYSUTCDATETIME())),
    ('00000000-0000-0000-0000-000000000103', 'u-42', N'invoice.pdf', N'u-42/c0ffee01.pdf',
     'Failed', DATEADD(MINUTE, -20, SYSUTCDATETIME())),
    ('00000000-0000-0000-0000-000000000104', 'u-41', N'holiday.jpg', N'u-41/5e8d0b33.jpg',
     'Processed', DATEADD(DAY, -3, SYSUTCDATETIME())),
    ('00000000-0000-0000-0000-000000000105', 'u-41', N'invoice.pdf', N'u-41/a17b44f2.pdf',
     'Failed', DATEADD(MINUTE, -15, SYSUTCDATETIME())),
    ('00000000-0000-0000-0000-000000000106', 'u-43', N'thesis.docx', N'u-43/3d2e9a80.docx',
     'Pending', DATEADD(MINUTE, -10, SYSUTCDATETIME())),
    ('00000000-0000-0000-0000-000000000107', 'u-43', N'salaries.xlsx', N'u-43/e4b9c6d1.xlsx',
     'Processed', DATEADD(DAY, -10, SYSUTCDATETIME())),
    ('00000000-0000-0000-0000-000000000108', 'u-41', N'scan.pdf', N'u-41/8a6f1c25.pdf',
     'Failed', DATEADD(MINUTE, -5, SYSUTCDATETIME()));

SELECT d.DocumentId, o.DisplayName AS owner_name, d.OriginalName, d.Status
FROM dbo.Documents AS d
JOIN dbo.Owners AS o ON o.OwnerId = d.OwnerId
ORDER BY d.DocumentId;
