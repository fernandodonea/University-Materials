-- Lab 5 - Step 11: the page "Failed today", newest first. Run it as the user of the API:
--   sqlcmd $AS_APP -i sql/07-failed-today.sql
-- STATISTICS IO prints how many 8 KB pages the query read: look for "logical reads".

SET STATISTICS IO ON;

SELECT TOP (20) DocumentId, OriginalName, CreatedAtUtc
FROM dbo.Documents
WHERE Status = 'Failed' AND CreatedAtUtc >= CAST(SYSUTCDATETIME() AS DATE)
ORDER BY CreatedAtUtc DESC;
